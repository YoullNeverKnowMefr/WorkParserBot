"""Diagnostic launch: watch source channels live WITHOUT forwarding/publishing.

Run:  python test_run.py
It prints every new message from SOURCE_CHANNELS and whether it matches the
keywords — so you can tell if updates arrive and if the filter works.
Requires an already-authorized session (run login first if needed).
"""
import asyncio
import json
import os

from telethon import TelegramClient, events

import config

# --- load the same keywords the bot uses (keywords.json overrides .env) --------
KEYWORDS = config.KEYWORDS
_kp = str(config.BASE_DIR / "keywords.json")
if os.path.exists(_kp):
    try:
        data = json.loads(open(_kp, encoding="utf-8").read())
        kws = [str(k).strip().lower() for k in data if str(k).strip()]
        if kws:
            KEYWORDS = kws
    except Exception as exc:  # noqa: BLE001
        print("keywords.json load failed:", exc)


def is_vacancy(text):
    if not text:
        return False
    low = text.lower()
    return any(kw in low for kw in KEYWORDS)


user = TelegramClient(config.SESSION, config.API_ID, config.API_HASH)


@user.on(events.NewMessage(chats=config.SOURCE_CHANNELS))
async def watch(event):
    chat = await event.get_chat()
    name = getattr(chat, "title", event.chat_id)
    preview = (event.raw_text or "")[:80].replace("\n", " ")
    match = is_vacancy(event.raw_text)
    mark = "✅ MATCH" if match else "— skip "
    print(f"[{mark}] {name}: {preview}")


async def main():
    await user.connect()
    if not await user.is_user_authorized():
        print("❌ Аккаунт НЕ авторизован. Сначала войди (login.py).")
        return
    me = await user.get_me()
    print(f"✅ Наблюдатель: {me.first_name} (id={me.id})")
    print(f"Ключевых слов: {len(KEYWORDS)} -> {', '.join(KEYWORDS)}")
    print(f"Каналов-источников в конфиге: {len(config.SOURCE_CHANNELS)}\n")

    # membership check
    dialog_ids = set()
    async for d in user.iter_dialogs():
        dialog_ids.add(d.id)

    print("=== Проверка подписки на источники ===")
    for ch in config.SOURCE_CHANNELS:
        try:
            ent = await user.get_entity(ch)
            joined = ent.id in dialog_ids
            print(f"  {ch}: id={ent.id} подписан={'ДА' if joined else 'НЕТ ⚠️'}")
        except Exception as exc:  # noqa: BLE001
            print(f"  {ch}: ОШИБКА доступа -> {exc}")

    print("\n👀 Слушаю новые сообщения. Запости что-нибудь в канал-источник.")
    print("   Каждое новое сообщение появится ниже. Ctrl+C для выхода.\n")
    await user.run_until_disconnected()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nОстановлено.")
